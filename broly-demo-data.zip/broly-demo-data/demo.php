<?php
$file_url = plugin_dir_path( __FILE__ ) . 'demo-data/';
$image_url  = plugin_dir_url( __FILE__ ) . 'previews/';
$demo_array = array(
    'main-default' => array(
        'title' 		=> 'Default Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-01.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-default.json',
        'option' 		=> $file_url . 'option-default.json',
        'preview'		=> $image_url  . 'default.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Home',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_url'      => 'http://broly.la-studioweb.com/'
    ),
    'main-creative' => array(
        'title' 		=> 'Creative Homepage',
        'tags'          => 'Creative',
        'slider' 		=> $file_url . 'main-creative.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-default.json',
        'option' 		=> $file_url . 'option-creative.json',
        'preview'		=> $image_url  . 'creative.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Creative',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-creative',
        'demo_url'      => 'http://broly.la-studioweb.com/main-creative'
    ),
    'main-simple' => array(
        'title' 		=> 'Simple Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-simple.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-simple.json',
        'option' 		=> $file_url . 'option-simple.json',
        'preview'		=> $image_url  . 'simple.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Simple',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-simple',
        'demo_url'      => 'http://broly.la-studioweb.com/main-simple'
    ),
    'main-shop' => array(
        'title' 		=> 'Shop Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-shop.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-shop.json',
        'option' 		=> $file_url . 'option-shop.json',
        'preview'		=> $image_url  . 'shop.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Shop',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-shop',
        'demo_url'      => 'http://broly.la-studioweb.com/main-shop'
    ),
    'main-corporate' => array(
        'title' 		=> 'Corporate Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-corporate.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-corporate.json',
        'option' 		=> $file_url . 'option-corporate.json',
        'preview'		=> $image_url  . 'corporate.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Corporate',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-corporate',
        'demo_url'      => 'http://broly.la-studioweb.com/main-corporate'
    ),
    'main-construction' => array(
        'title' 		=> 'Construction Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-construction.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-construction.json',
        'option' 		=> $file_url . 'option-construction.json',
        'preview'		=> $image_url  . 'construction.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Construction',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-construction',
        'demo_url'      => 'http://broly.la-studioweb.com/main-construction'
    ),
    'main-spa' => array(
        'title' 		=> 'Spa Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-spa.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-spa.json',
        'option' 		=> $file_url . 'option-spa.json',
        'preview'		=> $image_url  . 'spa.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Spa',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-spa',
        'demo_url'      => 'http://broly.la-studioweb.com/main-spa'
    ),
    'main-photography' => array(
        'title' 		=> 'Photography Homepage',
        'tags'          => 'Photography',
        'slider' 		=> $file_url . 'main-photography.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-photography.json',
        'option' 		=> $file_url . 'option-photography.json',
        'preview'		=> $image_url  . 'photography.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Photography',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-photography',
        'demo_url'      => 'http://broly.la-studioweb.com/main-photography'
    ),
    'main-restaurant' => array(
        'title' 		=> 'Restaurant Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-restaurant.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-restaurant.json',
        'option' 		=> $file_url . 'option-restaurant.json',
        'preview'		=> $image_url  . 'restaurant.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Restaurant',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-restaurant',
        'demo_url'      => 'http://broly.la-studioweb.com/main-restaurant'
    ),
    'main-wedding' => array(
        'title' 		=> 'Wedding Homepage',
        'tags'          => 'Wedding',
        'slider' 		=> $file_url . 'main-wedding.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-wedding.json',
        'option' 		=> $file_url . 'option-wedding.json',
        'preview'		=> $image_url  . 'wedding.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Wedding',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-wedding',
        'demo_url'      => 'http://broly.la-studioweb.com/main-wedding'
    ),
    'main-education' => array(
        'title' 		=> 'Education Homepage',
        'tags'          => 'Education',
        'slider' 		=> $file_url . 'main-education.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-education.json',
        'option' 		=> $file_url . 'option-education.json',
        'preview'		=> $image_url  . 'education.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Education',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-education',
        'demo_url'      => 'http://broly.la-studioweb.com/main-education'
    ),
    'main-hosting' => array(
        'title' 		=> 'Hosting Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-hosting.zip',
        'content' 		=> $file_url . 'main-hosting.xml',
        'widget' 		=> $file_url . 'widget-hosting.json',
        'option' 		=> $file_url . 'option-hosting.json',
        'preview'		=> $image_url  . 'hosting.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Hosting',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-hosting',
        'demo_url'      => 'http://broly.la-studioweb.com/main-hosting'
    ),
    'main-blog' => array(
        'title' 		=> 'Blog Homepage',
        'tags'          => 'Blog',
        'slider' 		=> $file_url . 'main-blog.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-blog.json',
        'option' 		=> $file_url . 'option-blog.json',
        'preview'		=> $image_url  . 'blog.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Blog',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-blog',
        'demo_url'      => 'http://broly.la-studioweb.com/main-blog'
    ),
    'main-app' => array(
        'title' 		=> 'App Homepage',
        'tags'          => '',
        'slider' 		=> $file_url . 'main-app.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-app.json',
        'option' 		=> $file_url . 'option-app.json',
        'preview'		=> $image_url  . 'app.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main App',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-app',
        'demo_url'      => 'http://broly.la-studioweb.com/main-app'
    ),
    'main-freelancer' => array(
        'title' 		=> 'Freelancer Homepage',
        'tags'          => 'Freelancer',
        'slider' 		=> $file_url . 'main-freelancer.zip',
        'content' 		=> $file_url . 'data-sample.xml',
        'widget' 		=> $file_url . 'widget-freelancer.json',
        'option' 		=> $file_url . 'option-freelancer.json',
        'preview'		=> $image_url  . 'freelancer.jpg',
        'menu-locations'=> array(
            'main-nav' 		=> 'Main Navigation',
        ),
        'pages'			=> array(
            'page_on_front' 	=> 'Main Freelancer',
            'page_for_posts' 	=> 'Blog'
        ),
        'demo_preset'   => 'main-freelancer',
        'demo_url'      => 'http://broly.la-studioweb.com/main-freelancer'
    )
);